/* ###
 * IP: GHIDRA
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ghidra.pcode.emulate;

import ghidra.pcode.error.LowlevelError;
import ghidra.pcode.pcoderaw.PcodeOpRaw;

@Deprecated(since = "12.1", forRemoval = true)
public class UnimplementedCallOtherException extends LowlevelError {

	private String opName;
	private PcodeOpRaw op;

	public UnimplementedCallOtherException(PcodeOpRaw op, String opName) {
		super("Unimplemented CALLOTHER pcodeop (" + opName + "), PC=" + op.getAddress());
		this.op = op;
		this.opName = opName;
	}

	public PcodeOpRaw getCallOtherOp() {
		return op;
	}

	public String getCallOtherOpName() {
		return opName;
	}

}
