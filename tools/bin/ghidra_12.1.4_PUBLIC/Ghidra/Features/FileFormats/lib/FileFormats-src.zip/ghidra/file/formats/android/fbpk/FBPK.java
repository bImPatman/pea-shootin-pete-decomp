/* ###
 * IP: GHIDRA
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ghidra.file.formats.android.fbpk;

import java.util.List;

import ghidra.app.util.bin.StructConverter;

public interface FBPK extends StructConverter {
	/**
	 * Returns the MAGIC value.
	 * @return the MAGIC value
	 */
	public int getMagic();
	/**
	 * Returns the version.
	 * @return the version
	 */
	public int getVersion();
	/**
	 * Returns the list of partitions.
	 * @return the list of partitions
	 */
	public List<FBPK_Partition> getPartitions();
}
